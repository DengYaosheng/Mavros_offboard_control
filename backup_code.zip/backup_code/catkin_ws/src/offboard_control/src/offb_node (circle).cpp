#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/State.h>
#include <vector>
#include <math.h>

mavros_msgs::State current_state;
geometry_msgs::PoseStamped current_position;

// State callback
void state_cb(const mavros_msgs::State::ConstPtr& msg){
    current_state = *msg;
}

// Position callback
void position_cb(const geometry_msgs::PoseStamped::ConstPtr& msg){
    current_position = *msg;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "offb_node");
    ros::NodeHandle nh;

    ros::Subscriber state_sub = nh.subscribe<mavros_msgs::State>
            ("mavros/state", 10, state_cb);
    ros::Subscriber position_sub = nh.subscribe<geometry_msgs::PoseStamped>
            ("mavros/local_position/pose", 10, position_cb);
    ros::Publisher local_pos_pub = nh.advertise<geometry_msgs::PoseStamped>
            ("mavros/setpoint_position/local", 10);
    ros::ServiceClient arming_client = nh.serviceClient<mavros_msgs::CommandBool>
            ("mavros/cmd/arming");
    ros::ServiceClient set_mode_client = nh.serviceClient<mavros_msgs::SetMode>
            ("mavros/set_mode");

    ros::Rate rate(20.0);

    // Wait for FCU connection
    while(ros::ok() && !current_state.connected){
        ros::spinOnce();
        rate.sleep();
    }

    // Define the list of waypoints in 3D space (circle path)
    std::vector<geometry_msgs::PoseStamped> waypoints;
    float radius = 5.0;
    float altitude = 2.0;
    int num_points = 20;
    for (int i = 0; i < num_points; ++i) {
        float angle = 2 * M_PI * i / num_points;
        geometry_msgs::PoseStamped waypoint;
        waypoint.pose.position.x = radius * cos(angle);
        waypoint.pose.position.y = radius * sin(angle);
        waypoint.pose.position.z = altitude;
        waypoints.push_back(waypoint);
    }

    // Send a few initial setpoints to initialize OFFBOARD mode
    for(int i = 100; ros::ok() && i > 0; --i){
        local_pos_pub.publish(waypoints[0]);
        ros::spinOnce();
        rate.sleep();
    }

    // Set OFFBOARD mode and arm the drone
    mavros_msgs::SetMode offb_set_mode;
    offb_set_mode.request.custom_mode = "OFFBOARD";

    mavros_msgs::CommandBool arm_cmd;
    arm_cmd.request.value = true;

    ros::Time last_request = ros::Time::now();

    int waypoint_index = 0;

    while(ros::ok()){
        // Set mode to OFFBOARD and arm the drone
        if( current_state.mode != "OFFBOARD" &&
            (ros::Time::now() - last_request > ros::Duration(5.0))){
            if( set_mode_client.call(offb_set_mode) &&
                offb_set_mode.response.mode_sent){
                ROS_INFO("Offboard enabled");
            }
            last_request = ros::Time::now();
        } else {
            if( !current_state.armed &&
                (ros::Time::now() - last_request > ros::Duration(5.0))){
                if( arming_client.call(arm_cmd) &&
                    arm_cmd.response.success){
                    ROS_INFO("Vehicle armed");
                }
                last_request = ros::Time::now();
            }
        }

        // Publish the current waypoint
        local_pos_pub.publish(waypoints[waypoint_index]);

        // Calculate distance to the current waypoint
        float dx = current_position.pose.position.x - waypoints[waypoint_index].pose.position.x;
        float dy = current_position.pose.position.y - waypoints[waypoint_index].pose.position.y;
        float dz = current_position.pose.position.z - waypoints[waypoint_index].pose.position.z;
        float distance = sqrt(dx*dx + dy*dy + dz*dz);

        // If the drone is close to the waypoint, switch to the next
        if (distance < 0.5) {
            waypoint_index = (waypoint_index + 1) % waypoints.size();
            ROS_INFO("Moving to waypoint %d", waypoint_index);
        }

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}

