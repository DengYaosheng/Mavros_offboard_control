#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/State.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <iostream>

mavros_msgs::State current_state;
geometry_msgs::PoseStamped current_position;

// State callback
void state_cb(const mavros_msgs::State::ConstPtr& msg){
    current_state = *msg;
}

// Position callback
void position_cb(const geometry_msgs::PoseStamped::ConstPtr& msg){
    current_position = *msg;
}

// Function to load positions from a CSV file
std::vector<geometry_msgs::PoseStamped> load_positions_from_csv(const std::string& file_path) {
    std::vector<geometry_msgs::PoseStamped> positions;
    std::ifstream file(file_path);
    std::string line;

    if (!file.is_open()) {
        std::cerr << "Error: Could not open file " << file_path << std::endl;
        return positions;
    }

    std::cout << "Opening file: " << file_path << std::endl;

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string value;
        geometry_msgs::PoseStamped pose;

        // Parse x, y, z values
        if (!std::getline(ss, value, ',')) break;
        pose.pose.position.x = std::stof(value);
        
        if (!std::getline(ss, value, ',')) break;
        pose.pose.position.y = std::stof(value);
        
        if (!std::getline(ss, value, ',')) break;
        pose.pose.position.z = std::stof(value);

        positions.push_back(pose);
    }

    std::cout << "Loaded " << positions.size() << " positions from CSV." << std::endl;
    return positions;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "offb_node");
    ros::NodeHandle nh;

    ros::Subscriber state_sub = nh.subscribe<mavros_msgs::State>
            ("mavros/state", 10, state_cb);
    ros::Subscriber position_sub = nh.subscribe<geometry_msgs::PoseStamped>
            ("mavros/local_position/pose", 10, position_cb);
    ros::Publisher local_pos_pub = nh.advertise<geometry_msgs::PoseStamped>
            ("mavros/setpoint_position/local", 10);
    ros::ServiceClient arming_client = nh.serviceClient<mavros_msgs::CommandBool>
            ("mavros/cmd/arming");
    ros::ServiceClient set_mode_client = nh.serviceClient<mavros_msgs::SetMode>
            ("mavros/set_mode");

    ros::Rate rate(20.0);

    // Wait for FCU connection
    while(ros::ok() && !current_state.connected){
        ROS_INFO("Waiting for FCU connection...");
        ros::spinOnce();
        rate.sleep();
    }

    // Load positions from CSV file
    std::string file_path = "/home/yaosheng/catkin_ws/src/offboard_control/src/positions1.csv";
    std::vector<geometry_msgs::PoseStamped> waypoints = load_positions_from_csv(file_path);

    // Check if waypoints loaded successfully
    if (waypoints.empty()) {
        ROS_ERROR("No waypoints loaded from CSV. Exiting...");
        return -1;
    }

    // Send a few initial setpoints to initialize OFFBOARD mode
    for(int i = 100; ros::ok() && i > 0; --i){
        local_pos_pub.publish(waypoints[0]);
        ros::spinOnce();
        rate.sleep();
    }

    // Set OFFBOARD mode and attempt to arm the drone
    mavros_msgs::SetMode offb_set_mode;
    offb_set_mode.request.custom_mode = "OFFBOARD";

    mavros_msgs::CommandBool arm_cmd;
    arm_cmd.request.value = true;

    ros::Time last_request = ros::Time::now();
    int waypoint_index = 0;

    // Main loop with checks for offboard and arming
    while (ros::ok()) {
        // Check and set OFFBOARD mode
        if (current_state.mode != "OFFBOARD" && (ros::Time::now() - last_request > ros::Duration(5.0))) {
            if (set_mode_client.call(offb_set_mode) && offb_set_mode.response.mode_sent) {
                ROS_INFO("Offboard enabled");
            } else {
                ROS_WARN("Failed to enable Offboard mode");
            }
            last_request = ros::Time::now();
        }
        else{
        // Check and arm the vehicle
        if (!current_state.armed && 
            (ros::Time::now() - last_request > ros::Duration(5.0))) {
            bool arming_call_result = arming_client.call(arm_cmd);
    	    bool arming_response_success = arm_cmd.response.success;
    	    
    	 if (arming_call_result) {
             if (arming_response_success) {
                 ROS_INFO("Vehicle armed successfully.");
            } else {
                ROS_WARN("Arming failed: arming_call_result = true, but arm_cmd.response.success = false");
        }
         } else {
        ROS_ERROR("Arming service call failed: arming_call_result = false.");
    }
    	    
            if (arming_client.call(arm_cmd) && arm_cmd.response.success) {
                ROS_INFO("Vehicle armed");
            } else {
                ROS_WARN("Failed to arm vehicle. Retrying...");
            }
            last_request = ros::Time::now();
        }
        }

        // Start waypoint tracking only after both arming and OFFBOARD mode are successful
        if (current_state.armed && current_state.mode == "OFFBOARD") {
            local_pos_pub.publish(waypoints[waypoint_index]);
            ROS_INFO("Waypoint %d: x=%f, y=%f, z=%f", waypoint_index,
                     waypoints[waypoint_index].pose.position.x,
                     waypoints[waypoint_index].pose.position.y,
                     waypoints[waypoint_index].pose.position.z);

            // Calculate the distance to the current waypoint
            float dx = current_position.pose.position.x - waypoints[waypoint_index].pose.position.x;
            float dy = current_position.pose.position.y - waypoints[waypoint_index].pose.position.y;
            float dz = current_position.pose.position.z - waypoints[waypoint_index].pose.position.z;
            float distance = sqrt(dx*dx + dy*dy + dz*dz);

            // Move to the next waypoint if close to the current one
            if (distance < 0.5) {
                waypoint_index++;
                ROS_INFO("Moving to waypoint %d", waypoint_index);
                if (waypoint_index >= waypoints.size()) {
                    ROS_INFO("All waypoints completed.");
                    break;
                }
            }
        }

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}

