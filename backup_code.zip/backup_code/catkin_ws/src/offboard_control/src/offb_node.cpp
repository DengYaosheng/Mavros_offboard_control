#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/State.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>

mavros_msgs::State current_state;
std::vector<geometry_msgs::PoseStamped> waypoints;  // Vector to hold waypoints

// State callback to monitor FCU connection and arming state
void state_cb(const mavros_msgs::State::ConstPtr& msg){
    current_state = *msg;
}

// Function to load positions from CSV file
std::vector<geometry_msgs::PoseStamped> load_positions_from_csv(const std::string& file_path) {
    std::vector<geometry_msgs::PoseStamped> positions;
    std::ifstream file(file_path);
    std::string x_line, y_line, z_line;

    if (!file.is_open()) {
        std::cerr << "Error: Could not open file " << file_path << std::endl;
        return positions;
    }

    std::cout << "Opening file: " << file_path << std::endl;

    // Read three lines from the file: one each for x, y, and z positions
    if (std::getline(file, x_line) && std::getline(file, y_line) && std::getline(file, z_line)) {
        std::stringstream x_ss(x_line);
        std::stringstream y_ss(y_line);
        std::stringstream z_ss(z_line);
        std::string x_val, y_val, z_val;
        
        // Read each column value in sequence
        while (std::getline(x_ss, x_val, ',') && std::getline(y_ss, y_val, ',') && std::getline(z_ss, z_val, ',')) {
            geometry_msgs::PoseStamped pose;
            pose.pose.position.x = std::stof(x_val);
            pose.pose.position.y = std::stof(y_val);
            pose.pose.position.z = std::stof(z_val);

            positions.push_back(pose);
        }
    }

    std::cout << "Total positions loaded: " << positions.size() << std::endl;
    return positions;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "offb_node");
    ros::NodeHandle nh;

    ros::Subscriber state_sub = nh.subscribe<mavros_msgs::State>
            ("mavros/state", 10, state_cb);
    ros::Publisher local_pos_pub = nh.advertise<geometry_msgs::PoseStamped>
            ("mavros/setpoint_position/local", 10);
    ros::ServiceClient arming_client = nh.serviceClient<mavros_msgs::CommandBool>
            ("mavros/cmd/arming");
    ros::ServiceClient set_mode_client = nh.serviceClient<mavros_msgs::SetMode>
            ("mavros/set_mode");

    ros::Rate rate(20.0);

    // Wait for FCU connection
    while(ros::ok() && !current_state.connected){
        ROS_INFO("Waiting for FCU connection...");
        ros::spinOnce();
        rate.sleep();
    }

    // Load positions from CSV file
    std::string file_path = "/home/yaosheng/catkin_ws/src/offboard_control/src/positions1.csv";
    waypoints = load_positions_from_csv(file_path);

    if (waypoints.empty()) {
        ROS_ERROR("No waypoints loaded from CSV. Exiting...");
        return -1;
    }

    // Use a fixed initial position for arming
    geometry_msgs::PoseStamped initial_pose;
    initial_pose.pose.position.x = 0;
    initial_pose.pose.position.y = 0;
    initial_pose.pose.position.z = 2;

    // Send initial setpoints to switch to OFFBOARD mode
    for(int i = 100; ros::ok() && i > 0; --i){
        local_pos_pub.publish(initial_pose);  // Publish a stable hover position
        ros::spinOnce();
        rate.sleep();
    }

    // Set OFFBOARD mode and arm the UAV
    mavros_msgs::SetMode offb_set_mode;
    offb_set_mode.request.custom_mode = "OFFBOARD";

    mavros_msgs::CommandBool arm_cmd;
    arm_cmd.request.value = true;

    ros::Time last_request = ros::Time::now();
    size_t waypoint_index = 0;

    while(ros::ok()){
        // Set OFFBOARD mode if not already set
        if( current_state.mode != "OFFBOARD" &&
            (ros::Time::now() - last_request > ros::Duration(5.0))){
            if( set_mode_client.call(offb_set_mode) &&
                offb_set_mode.response.mode_sent){
                ROS_INFO("Offboard enabled");
            } else {
                ROS_WARN("Failed to set Offboard mode.");
            }
            last_request = ros::Time::now();
        }

        // Arm the vehicle if not already armed
        if( !current_state.armed &&
            (ros::Time::now() - last_request > ros::Duration(5.0))){
            if( arming_client.call(arm_cmd) &&
                arm_cmd.response.success){
                ROS_INFO("Vehicle armed successfully.");
            } else {
                ROS_WARN("Arming rejected by PX4.");
            }
            last_request = ros::Time::now();
        }

        // Switch to following CSV waypoints once armed and in OFFBOARD mode
        if (current_state.armed && current_state.mode == "OFFBOARD") {
            if (waypoint_index < waypoints.size()) {
                local_pos_pub.publish(waypoints[waypoint_index]);
                ROS_INFO("Moving to waypoint %zu: x=%f, y=%f, z=%f", 
                         waypoint_index,
                         waypoints[waypoint_index].pose.position.x,
                         waypoints[waypoint_index].pose.position.y,
                         waypoints[waypoint_index].pose.position.z);
                waypoint_index++;
            } else {
                ROS_INFO("Completed all waypoints.");
                break;
            }
        } else {
            // Continue publishing the initial position to maintain OFFBOARD mode
            local_pos_pub.publish(initial_pose);
        }

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}

