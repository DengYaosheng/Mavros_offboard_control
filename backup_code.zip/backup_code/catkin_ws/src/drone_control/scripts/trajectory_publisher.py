#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import PoseStamped
from mavros_msgs.srv import CommandBool, SetMode
from mavros_msgs.msg import State

class TrajectoryPublisher:
    def __init__(self):
        rospy.init_node('trajectory_publisher', anonymous=True)

        # Publishers and Subscribers
        self.state_sub = rospy.Subscriber('/mavros/state', State, self.state_callback)
        self.publisher = rospy.Publisher('/mavros/setpoint_position/local', PoseStamped, queue_size=10)

        # Service proxies for arming and mode setting
        self.arming_client = rospy.ServiceProxy('/mavros/cmd/arming', CommandBool)
        self.set_mode_client = rospy.ServiceProxy('/mavros/set_mode', SetMode)

        # Drone state and trajectory variables
        self.current_state = State()
        self.trajectory = [
            (0, 0, 2),  # Starting point
            (5, 0, 2),
            (5, 5, 2),
            (0, 5, 2),
            (0, 0, 2)   # Return to start
        ]
        self.current_index = 0

    def state_callback(self, state):
        self.current_state = state

    def set_mode(self, mode):
        rospy.wait_for_service('/mavros/set_mode')
        try:
            response = self.set_mode_client(custom_mode=mode)
            rospy.loginfo(f"Mode set to {mode}: {response.mode_sent}")
        except rospy.ServiceException as e:
            rospy.logerr(f"Failed to set mode: {e}")

    def arm_drone(self, arm=True):
        rospy.wait_for_service('/mavros/cmd/arming')
        try:
            response = self.arming_client(value=arm)
            rospy.loginfo(f"Arming command ({'ARM' if arm else 'DISARM'}): {response.success}")
        except rospy.ServiceException as e:
            rospy.logerr(f"Failed to arm/disarm: {e}")

    def publish_trajectory(self):
        # Start by sending a few initial setpoints before switching to OFFBOARD
        rate = rospy.Rate(10)  # Hz
        pose = PoseStamped()
        pose.pose.position.x, pose.pose.position.y, pose.pose.position.z = self.trajectory[0]

        for _ in range(100):
            self.publisher.publish(pose)
            rate.sleep()

        # Set to OFFBOARD mode and arm the drone
        self.set_mode("OFFBOARD")
        self.arm_drone(True)

        # Publish trajectory
        while not rospy.is_shutdown() and self.current_index < len(self.trajectory):
            x, y, z = self.trajectory[self.current_index]
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.position.z = z
            self.publisher.publish(pose)
            rospy.loginfo(f"Published position: x={x}, y={y}, z={z}")
            self.current_index += 1
            rate.sleep()

        # Disarm the drone after finishing
        self.arm_drone(False)

if __name__ == '__main__':
    traj_pub = TrajectoryPublisher()
    traj_pub.publish_trajectory()

