Initial attempt to try some things out for offboard control.
Mostly a sandbox to get my bearing at this point.
