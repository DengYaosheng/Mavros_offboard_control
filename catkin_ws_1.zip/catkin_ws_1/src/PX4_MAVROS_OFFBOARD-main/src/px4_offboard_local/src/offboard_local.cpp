#include <ros/ros.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/State.h>
#include <mavros_msgs/SetMode.h>

#include <mavros_msgs/Altitude.h>
#include <mavros_msgs/Mavlink.h>
#include <geographic_msgs/GeoPoseStamped.h>
#include <geometry_msgs/PoseStamped.h>

//   geographic_msgs
//   geometry_msgs

