#!/usr/bin/env python

import rospy
import math
from geometry_msgs.msg import TwistStamped
from nav_msgs.msg import Odometry

class VelocityController:
    def __init__(self):
        self.vel_pub = rospy.Publisher('/mavros/setpoint_velocity/cmd_vel', TwistStamped, queue_size=10)
        self.pos_sub = rospy.Subscriber('/mavros/local_position/odom', Odometry, self.odom_callback)
        self.current_position = None

    def odom_callback(self, data):
        self.current_position = data.pose.pose.position

    def run(self):
        rate = rospy.Rate(20)  # 20 Hz
        while not rospy.is_shutdown():
            if self.current_position:
                t = rospy.Time.now().to_sec()
                x = self.current_position.x
                y = self.current_position.y
                z = self.current_position.z

                new_velocity = TwistStamped()
                new_velocity.twist.linear.x = x + math.sin(t)
                new_velocity.twist.linear.y = y + math.sin(t)
                new_velocity.twist.linear.z = z + math.sin(t)
                rospy.loginfo("Publishing velocity: x={}, y={}, z={}".format(u,u,u))
                self.vel_pub.publish(new_velocity)
            rate.sleep()

if __name__ == '__main__':
    rospy.init_node('velocity_controller')
    controller = VelocityController()
    controller.run()
